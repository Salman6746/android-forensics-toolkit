# Android Forensics Toolkit

Educational forensic project using ADB.

## Features
- Device detection
- Data extraction
- Auto analysis
- Report generation

## Run
python main.py
