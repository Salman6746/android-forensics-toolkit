import os
from analyzer import analyze_data
from report import generate_report

def run():
    print('ANDROID FORENSICS TOOLKIT')
    os.system('adb devices')

    os.makedirs('forensic_data', exist_ok=True)

    os.system('adb pull /sdcard/DCIM forensic_data/DCIM')
    os.system('adb pull /sdcard/Download forensic_data/Download')

    images, videos, docs = analyze_data()
    generate_report(images, videos, docs)

if __name__ == '__main__':
    run()
