import datetime

def generate_report(images, videos, docs):
    with open('forensic_report.txt','w') as f:
        f.write('FORENSIC REPORT\n')
        f.write(str(datetime.datetime.now()) + '\n')
        f.write(f'Images: {images}\n')
        f.write(f'Videos: {videos}\n')
        f.write(f'Documents: {docs}\n')
