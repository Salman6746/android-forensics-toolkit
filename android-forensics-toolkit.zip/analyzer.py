import os

def analyze_data():
    images = videos = docs = 0

    for root, dirs, files in os.walk('forensic_data'):
        for f in files:
            f = f.lower()
            if f.endswith(('.jpg','.png','.jpeg')):
                images += 1
            elif f.endswith(('.mp4','.mkv')):
                videos += 1
            elif f.endswith(('.pdf','.docx','.txt')):
                docs += 1

    return images, videos, docs
